package com.example.uniwash_be.mapper;

import com.example.uniwash_be.dto.StudentDormitoryDto;
import com.example.uniwash_be.entity.StudentDormitory;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface StudentDormitoryMapper {

    StudentDormitory toEntity(StudentDormitoryDto bookingDto);
    StudentDormitoryDto toDto(StudentDormitory booking);
    List<StudentDormitory> toEntities(List<StudentDormitoryDto> bookingDtos);
    List<StudentDormitoryDto> toDtos(List<StudentDormitory> bookings);

}
