package com.example.uniwash_be.mapper;

import com.example.uniwash_be.dto.UserDto;
import com.example.uniwash_be.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface UserMapper {

    User toEntity(UserDto userDto);
    UserDto toDto(User user);
    List<User> toEntities(List<UserDto> userDtos);
    List<UserDto> toDtos(List<User> users);

}
