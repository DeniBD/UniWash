package com.example.uniwash_be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniWashBeApplication {

    public static void main(String[] args) {
        SpringApplication.run(UniWashBeApplication.class, args);
    }

}
