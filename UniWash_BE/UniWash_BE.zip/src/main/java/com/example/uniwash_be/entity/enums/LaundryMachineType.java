package com.example.uniwash_be.entity.enums;

public enum LaundryMachineType {
    WASHING_MACHINE,
    DRYING_MACHINE
}