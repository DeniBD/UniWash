package com.example.uniwash_be.mapper;

import com.example.uniwash_be.dto.BookingDto;
import com.example.uniwash_be.entity.Booking;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface BookingMapper {

    Booking toEntity(BookingDto bookingDto);
    BookingDto toDto(Booking booking);
    List<Booking> toEntities(List<BookingDto> bookingDtos);
    List<BookingDto> toDtos(List<Booking> bookings);

}
