package com.example.uniwash_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniWashBeApplicationTests {

    @Test
    void contextLoads() {
    }

}
